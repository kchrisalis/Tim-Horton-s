// Tims Roll Up Rim Simulator
let playagain = 0;
let freecoffee = 0;
let freedonut = 0;
let grandprize = 0;

// Event Listener
document.getElementById("oneTime").addEventListener("click", runoneTime);
document.getElementById("fiveTimes").addEventListener("click", runfiveTimes);
document.getElementById("grandPrize").addEventListener("click", rungrandPrize);
document.getElementById("500donuts").addEventListener("click", run500donuts);

// Event Functions
// One Time
function runoneTime() {
  let randNum = Math.random();
  let provinceName = document.getElementById("provincetype").value;

  if (provinceName == "bcprovince") {
    if (randNum < 0.7) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.8) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.9) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
  } else if (provinceName == "abprovince") {
    if (randNum < 0.15) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.55) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.95) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
  } else if (provinceName == "skprovince") {
    if (randNum < 0.7) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.71) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.72) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
  }

  // Output
  document.getElementById("playagainnum").innerHTML = playagain;
  document.getElementById("freecoffeenum").innerHTML = freecoffee;
  document.getElementById("freedonutnum").innerHTML = freedonut;
  document.getElementById("grandprizenum").innerHTML = grandprize;
}

// Five Times
function runfiveTimes () {
  for (let n = 0; n < 5; n++) {
    let randNum = Math.random();
    let provinceName = document.getElementById("provincetype").value;
  
    if (provinceName == "bcprovince") {
      if (randNum < 0.7) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.8) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.9) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    } else if (provinceName == "abprovince") {
      if (randNum < 0.15) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.55) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.95) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    } else if (provinceName == "skprovince") {
      if (randNum < 0.7) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.71) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.72) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    }

    }
    // Output
    document.getElementById("playagainnum").innerHTML = playagain;
    document.getElementById("freecoffeenum").innerHTML = freecoffee;
    document.getElementById("freedonutnum").innerHTML = freedonut;
    document.getElementById("grandprizenum").innerHTML = grandprize;
}

// Grand Prize (must be refreshed after a grand prize is 1)
function rungrandPrize () {
  while (grandprize < 1) {
  let randNum = Math.random();
  let provinceName = document.getElementById("provincetype").value;

  if (provinceName == "bcprovince") {
    if (randNum < 0.7) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.8) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.9) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
  } else if (provinceName == "abprovince") {
    if (randNum < 0.15) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.55) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.95) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
  } else if (provinceName == "skprovince") {
    if (randNum < 0.7) {
      playagain++;
      document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
    } else if (randNum < 0.71) {
      freecoffee++;
      document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
    } else if (randNum < 0.72) {
      freedonut++;
      document.getElementById("result").innerHTML += '<img src="src/donut.png">'
    } else {
      grandprize++;
      document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
    }
    }
  }
  // Output
  document.getElementById("playagainnum").innerHTML = playagain;
  document.getElementById("freecoffeenum").innerHTML = freecoffee;
  document.getElementById("freedonutnum").innerHTML = freedonut;
  document.getElementById("grandprizenum").innerHTML = grandprize;
}

function run500donuts () {
  while (freedonut < 500) {
    let randNum = Math.random();
    let provinceName = document.getElementById("provincetype").value;
  
    if (provinceName == "bcprovince") {
      if (randNum < 0.7) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.8) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.9) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    } else if (provinceName == "abprovince") {
      if (randNum < 0.15) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.55) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.95) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    } else if (provinceName == "skprovince") {
      if (randNum < 0.7) {
        playagain++;
        document.getElementById("result").innerHTML += '<img src="src/playagain.jpeg">'
      } else if (randNum < 0.71) {
        freecoffee++;
        document.getElementById("result").innerHTML += '<img src="src/coffee.jpg">'
      } else if (randNum < 0.72) {
        freedonut++;
        document.getElementById("result").innerHTML += '<img src="src/donut.png">'
      } else {
        grandprize++;
        document.getElementById("result").innerHTML += '<img src="src/grandprize.jpg">'
      }
    }
  }
    // Output
    document.getElementById("playagainnum").innerHTML = playagain;
    document.getElementById("freecoffeenum").innerHTML = freecoffee;
    document.getElementById("freedonutnum").innerHTML = freedonut;
    document.getElementById("grandprizenum").innerHTML = grandprize;
  
}
